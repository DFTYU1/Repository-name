package com.example.qr_asset_tracker

import android.app.Application

class Application : Application() {
}

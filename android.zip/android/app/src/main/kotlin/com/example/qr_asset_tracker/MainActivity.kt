package com.example.qr_asset_tracker

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
